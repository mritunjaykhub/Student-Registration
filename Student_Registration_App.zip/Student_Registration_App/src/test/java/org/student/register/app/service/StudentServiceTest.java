package org.student.register.app.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.student.register.app.dao.repository.StudentRepository;
import org.student.register.app.model.Course;
import org.student.register.app.model.Student;


public class StudentServiceTest {

	@Mock
	private StudentRepository studentRepositoryMock;
	
	@Mock
	private CourseService courseServiceMock;

	@InjectMocks
	private StudentService studentService;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testAddCourse() {
		Student student = new Student();
		student.setStudentId(1l);
		Mockito.when(studentRepositoryMock.save(Mockito.any(Student.class))).thenReturn(student);
		Long courseId = studentService.addStudent(student);
		assertEquals(1, courseId.longValue());
	}

	@Test
	public void testRemoveCourse() {
		Long courseId = 1l;
		Student student = new Student();
		student.setStudentId(1l);
		Mockito.when(studentRepositoryMock.findById(Mockito.anyLong())).thenReturn(Optional.of(student));
		studentService.removeStudent(courseId);
	}

	@Test
	public void testRemoveCourseWithEmptyCourse() {
		Long courseId = 1l;
		Mockito.when(studentRepositoryMock.findById(Mockito.anyLong())).thenReturn(Optional.empty());
		studentService.removeStudent(courseId);
	}

	@Test
	public void testRegisterStudentToCourse() {
		Long studentId = 1l;
		Student source = new Student();
		source.setStudentId(studentId);
		source.setCourses(Collections.emptySet());
		Mockito.when(studentRepositoryMock.findById(Mockito.anyLong())).thenReturn(Optional.of(source));
		Set<Course> courses = Collections.emptySet();
		studentService.registerCourse(studentId, courses);

	}

	@Test
	public void testRegisterStudentToCoursEmptyCourse() {
		Long courseId = 1l;
		Mockito.when(studentRepositoryMock.findById(Mockito.anyLong())).thenReturn(Optional.empty());
		Set<Course> courses = Collections.emptySet();
		studentService.registerCourse(courseId, courses);

	}
	
	@Test
	public void testGetStudentsByCourseName() {
		String courseName = "DevOps";
		Course course = new Course();
		course.setCourseId(1l);
		course.setCourseName(courseName);
		
		Set<Student> studentsSet = new HashSet<>();
		
		Student student = new Student();
		student.setStudentName("NA");
		studentsSet.add(student);
		course.setStudents(studentsSet);
		course.setCourseName("NA");
		Mockito.when(courseServiceMock.getCourseByCourseName(Mockito.anyString())).thenReturn(Optional.of(course));
		Set<Student> students = studentService.getStudentsByCourseName(courseName);
		assertNotNull(students);
	}
	
	@Test
	public void testGetStudentsByCourseNameWithEmptyCourse() {
		String courseName = "DevOps";
		Mockito.when(courseServiceMock.getCourseByCourseName(Mockito.anyString())).thenReturn(Optional.empty());
		Set<Student> students = studentService.getStudentsByCourseName(courseName);
		assertNotNull(students);
	}

}
