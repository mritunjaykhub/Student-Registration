package org.student.register.app.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Collections;
import java.util.Optional;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.student.register.app.dao.repository.CourseRepository;
import org.student.register.app.model.Course;
import org.student.register.app.model.Student;

public class CourseServiceTest {

	@Mock
	private CourseRepository courseRepositoryMock;

	@InjectMocks
	private CourseService courseService;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testAddCourse() {
		Course course = new Course();
		course.setCourseId(2l);
		Mockito.when(courseRepositoryMock.save(Mockito.any(Course.class))).thenReturn(course);
		Long courseId = courseService.addCourse(course);
		assertEquals(2, courseId.longValue());
	}

	@Test
	public void testRemoveCourse() {
		Long courseId = 1l;
		Course course = new Course();
		course.setCourseId(courseId);
		course.setCourseName("Spring");
		Mockito.when(courseRepositoryMock.findById(Mockito.anyLong())).thenReturn(Optional.of(course));
		courseService.removeCourse(courseId);
	}
	
	@Test
	public void testRemoveCourseWithEmptyCourse() {
		Long courseId = 1l;
		Mockito.when(courseRepositoryMock.findById(Mockito.anyLong())).thenReturn(Optional.empty());
		courseService.removeCourse(courseId);
	}

	@Test
	public void testRegisterStudentToCourse() {
		Long courseId = 1l;
		Course course = new Course();
		course.setCourseId(courseId);
		course.setCourseName("Spring");
		course.setStudents(Collections.emptySet());
		Mockito.when(courseRepositoryMock.findById(Mockito.anyLong())).thenReturn(Optional.of(course));
		Set<Student> students = Collections.emptySet();
		courseService.registerStudentToCourse(courseId, students);

	}
	
	@Test
	public void testRegisterStudentToCoursEmptyCourse() {
		Long courseId = 1l;
		Mockito.when(courseRepositoryMock.findById(Mockito.anyLong())).thenReturn(Optional.empty());
		Set<Student> students = Collections.emptySet();
		courseService.registerStudentToCourse(courseId, students);

	}

	@Test
	public void testGetCourseByCourseName() {
		String courseName = "DevOps";
		courseService.getCourseByCourseName(courseName);
	}

}
