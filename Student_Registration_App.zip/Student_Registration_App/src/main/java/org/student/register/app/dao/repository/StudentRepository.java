package org.student.register.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.student.register.app.model.Student;



public interface StudentRepository extends JpaRepository<Student, Long> {

}
